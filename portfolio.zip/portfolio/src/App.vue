<script setup>
import { onMounted } from "vue";
import NavBar from "./components/NavBar.vue";
import HeroSection from "./components/HeroSection.vue";
import AboutMe from "./components/AboutMe.vue";
import FeaturedProjects from "./components/FeaturedProjects.vue";
import ToolkitSection from "./components/ToolkitSection.vue";
import ContactSection from "./components/ContactSection.vue";
import FooterSection from "./components/FooterSection.vue";

onMounted(() => {
  window.scrollTo({
    top: 0,
    left: 0,
    behavior: "instant",
  });
});
</script>

<template>
  <main class="w-full min-h-screen overflow-x-hidden">
    <NavBar />
    <HeroSection />
    <AboutMe />
    <ToolkitSection />
    <FeaturedProjects />
    <ContactSection />
    <FooterSection />
  </main>
</template>
