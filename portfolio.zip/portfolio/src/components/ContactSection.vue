<script setup>
import { ref, onMounted } from "vue";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const contactSection = ref(null);
const isModalOpen = ref(false);
const isSubmitting = ref(false);
const isSuccessModalOpen = ref(false);

onMounted(() => {
  // Gentle scale and fade-in for the main contact text
  gsap.from(".contact-content", {
    scrollTrigger: {
      trigger: contactSection.value,
      start: "top 75%",
      toggleActions: "play none none reverse",
    },
    y: 30,
    opacity: 0,
    scale: 0.95,
    duration: 0.8,
    ease: "power3.out",
  });
});

const submitForm = async () => {
  // 1. Start the loading animation
  isSubmitting.value = true;

  // 2. Simulate a network request delay (waiting 2 seconds)
  await new Promise((resolve) => setTimeout(resolve, 2000));

  // 3. Stop loading and close the main contact modal
  isSubmitting.value = false;
  isModalOpen.value = false;

  // 4. Open the Success confirmation modal
  isSuccessModalOpen.value = true;

  // 5. Automatically close the success modal after 3 seconds for a smooth experience
  setTimeout(() => {
    isSuccessModalOpen.value = false;
  }, 3000);
};
</script>

<template>
  <!-- Main Contact Section -->
  <section
    id="contact"
    ref="contactSection"
    class="relative flex min-h-screen flex-col items-center justify-between overflow-hidden bg-portfolio-base pt-32"
  >
    <!-- Background Grid Overlay (matches global body grid exactly) -->
    <div class="absolute inset-0 z-0 pointer-events-none grid-bg"></div>

    <!-- Centered Content -->
    <div
      class="contact-content relative z-10 flex flex-1 flex-col items-center justify-center px-6 text-center"
    >
      <p
        class="mb-4 text-[10px] font-bold uppercase tracking-[0.3em] text-portfolio-accent"
      >
        Get In Touch
      </p>

      <h2
        class="mb-8 text-6xl font-extrabold tracking-tight text-portfolio-text md:text-8xl"
      >
        Let's build <br class="hidden md:block" />
        something together.
      </h2>

      <p
        class="mb-10 max-w-xl text-sm leading-relaxed text-portfolio-muted md:text-base"
      >
        I'm currently looking for new opportunities. Whether you have a question
        or just want to say hi, my inbox is always open.
      </p>

      <!-- Trigger Button -->
      <button
        @click="isModalOpen = true"
        class="rounded-lg bg-portfolio-primary px-8 py-3.5 text-sm font-semibold text-white shadow-[0_0_20px_rgba(95,77,184,0.4)] transition-all hover:bg-portfolio-accent hover:text-portfolio-base hover:shadow-[0_0_25px_rgba(196,181,253,0.5)]"
      >
        Say Hello
      </button>
    </div>

    <!-- 1. Main Contact Form Modal -->
    <Teleport to="body">
      <Transition name="fade">
        <div
          v-if="isModalOpen"
          class="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-12"
        >
          <!-- Darkened Backdrop -->
          <div
            class="absolute inset-0 bg-portfolio-base/90 backdrop-blur-sm transition-opacity"
            @click="!isSubmitting && (isModalOpen = false)"
          ></div>

          <!-- Modal Card -->
          <div
            class="relative w-full max-w-5xl max-h-[85vh] flex flex-col overflow-y-auto overflow-x-hidden rounded-[24px] border border-white/10 bg-portfolio-surface shadow-2xl"
          >
            <!-- Modal Header -->
            <div
              class="sticky top-0 z-10 flex items-start justify-between border-b border-white/5 bg-portfolio-surface px-8 pb-6 pt-8"
            >
              <div>
                <p
                  class="mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-portfolio-accent"
                >
                  Start a conversation
                </p>
                <h2
                  class="text-3xl font-extrabold text-portfolio-text md:text-4xl"
                >
                  Let's work together
                </h2>
              </div>
              <!-- Disable close button while submitting -->
              <button
                :disabled="isSubmitting"
                @click="isModalOpen = false"
                class="flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-portfolio-muted transition-colors hover:bg-white/10 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
              >
                ✕
              </button>
            </div>

            <!-- Modal Body (Two Columns) -->
            <div class="grid grid-cols-1 md:grid-cols-[1fr_1.2fr]">
              <!-- Left Column: Info & Links -->
              <div
                class="border-b border-white/5 p-8 md:border-b-0 md:border-r"
              >
                <p
                  class="mb-4 text-[10px] font-bold uppercase tracking-[0.2em] text-portfolio-muted"
                >
                  Have a project in mind?
                </p>
                <h3
                  class="mb-6 text-3xl font-bold leading-tight text-portfolio-text md:text-4xl"
                >
                  Tell me what you're<br />building.
                </h3>
                <p class="mb-10 text-sm leading-relaxed text-portfolio-muted">
                  Have a project idea or want to talk about technology? Send me
                  a message. I'm always open to thoughtful collaborations and
                  new opportunities.
                </p>

                <!-- Contact Tags -->
                <div class="flex flex-col gap-4">
                  <div class="flex items-center gap-4">
                    <div
                      class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-white/5 bg-portfolio-base font-mono text-xs text-portfolio-muted"
                    >
                      @
                    </div>
                    <span class="text-sm text-portfolio-text"
                      >chowxinnlu@gmail.com</span
                    >
                  </div>

                  <div class="flex items-center gap-4">
                    <div
                      class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-white/5 bg-portfolio-base font-mono text-xs text-portfolio-muted"
                    >
                      GH
                    </div>
                    <span class="text-sm text-portfolio-text">@Chowayo</span>
                  </div>
                </div>
              </div>

              <!-- Right Column: Form -->
              <div class="bg-portfolio-base/30 p-8">
                <form @submit.prevent="submitForm" class="flex flex-col gap-6">
                  <!-- Name & Email Row -->
                  <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                    <div class="flex flex-col gap-2">
                      <label
                        class="text-[10px] font-bold uppercase tracking-widest text-portfolio-muted"
                        >Name</label
                      >
                      <input
                        type="text"
                        placeholder="Your name"
                        :disabled="isSubmitting"
                        required
                        class="rounded-lg border border-white/5 bg-portfolio-surface p-3.5 text-sm text-portfolio-text placeholder:text-portfolio-muted/40 transition-colors focus:border-portfolio-accent focus:outline-none focus:ring-1 focus:ring-portfolio-accent disabled:opacity-50"
                      />
                    </div>
                    <div class="flex flex-col gap-2">
                      <label
                        class="text-[10px] font-bold uppercase tracking-widest text-portfolio-muted"
                        >Email</label
                      >
                      <input
                        type="email"
                        placeholder="you@example.com"
                        :disabled="isSubmitting"
                        required
                        class="rounded-lg border border-white/5 bg-portfolio-surface p-3.5 text-sm text-portfolio-text placeholder:text-portfolio-muted/40 transition-colors focus:border-portfolio-accent focus:outline-none focus:ring-1 focus:ring-portfolio-accent disabled:opacity-50"
                      />
                    </div>
                  </div>

                  <!-- Subject -->
                  <div class="flex flex-col gap-2">
                    <label
                      class="text-[10px] font-bold uppercase tracking-widest text-portfolio-muted"
                      >Subject</label
                    >
                    <input
                      type="text"
                      placeholder="What would you like to build?"
                      :disabled="isSubmitting"
                      required
                      class="rounded-lg border border-white/5 bg-portfolio-surface p-3.5 text-sm text-portfolio-text placeholder:text-portfolio-muted/40 transition-colors focus:border-portfolio-accent focus:outline-none focus:ring-1 focus:ring-portfolio-accent disabled:opacity-50"
                    />
                  </div>

                  <!-- Message -->
                  <div class="flex flex-col gap-2">
                    <label
                      class="text-[10px] font-bold uppercase tracking-widest text-portfolio-muted"
                      >Message</label
                    >
                    <textarea
                      rows="5"
                      placeholder="Tell me about your idea..."
                      :disabled="isSubmitting"
                      required
                      class="resize-none rounded-lg border border-white/5 bg-portfolio-surface p-3.5 text-sm text-portfolio-text placeholder:text-portfolio-muted/40 transition-colors focus:border-portfolio-accent focus:outline-none focus:ring-1 focus:ring-portfolio-accent disabled:opacity-50"
                    ></textarea>
                  </div>

                  <!-- Submit Button with Dynamic State -->
                  <button
                    type="submit"
                    :disabled="isSubmitting"
                    class="mt-2 flex w-full items-center justify-center gap-2 rounded-lg bg-portfolio-primary py-4 text-sm font-semibold text-white shadow-[0_0_20px_rgba(95,77,184,0.3)] transition-all hover:bg-portfolio-accent hover:text-portfolio-base hover:shadow-[0_0_25px_rgba(196,181,253,0.5)] disabled:cursor-not-allowed disabled:opacity-75 disabled:hover:bg-portfolio-primary disabled:hover:text-white"
                  >
                    <template v-if="!isSubmitting">
                      Send Message <span>→</span>
                    </template>
                    <template v-else>
                      <svg
                        class="h-4 w-4 animate-spin text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          class="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          stroke-width="4"
                        ></circle>
                        <path
                          class="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Sending...
                    </template>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <!-- 2. Success Confirmation Modal -->
    <Teleport to="body">
      <Transition name="fade">
        <div
          v-if="isSuccessModalOpen"
          class="fixed inset-0 z-50 flex items-center justify-center p-4"
        >
          <!-- Darkened Backdrop -->
          <div
            class="absolute inset-0 bg-portfolio-base/90 backdrop-blur-sm transition-opacity"
            @click="isSuccessModalOpen = false"
          ></div>

          <!-- Success Card -->
          <div
            class="relative w-full max-w-sm flex flex-col items-center text-center overflow-hidden rounded-[24px] border border-white/10 bg-portfolio-surface p-8 shadow-2xl"
          >
            <!-- Animated Checkmark Icon -->
            <div
              class="mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-teal-500/20 text-teal-400"
            >
              <svg
                class="h-8 w-8"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M5 13l4 4L19 7"
                ></path>
              </svg>
            </div>

            <h3 class="mb-2 text-2xl font-bold text-portfolio-text">
              Message Sent!
            </h3>
            <p class="mb-8 text-sm leading-relaxed text-portfolio-muted">
              Thanks for reaching out. I'll get back to you as soon as possible.
            </p>

            <button
              @click="isSuccessModalOpen = false"
              class="w-full rounded-lg bg-white/5 py-3.5 text-sm font-semibold text-portfolio-text transition-colors hover:bg-white/10 hover:text-white"
            >
              Close
            </button>
          </div>
        </div>
      </Transition>
    </Teleport>
  </section>
</template>

<style scoped>
.grid-bg {
  background-size: 48px 48px;
  background-image:
    linear-gradient(to right, rgba(148, 163, 184, 0.06) 1px, transparent 1px),
    linear-gradient(to bottom, rgba(148, 163, 184, 0.06) 1px, transparent 1px);
}

/* Vue Transition Classes for Modal */
.fade-enter-active,
.fade-leave-active {
  transition:
    opacity 0.3s ease,
    transform 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: scale(0.98);
}
</style>
