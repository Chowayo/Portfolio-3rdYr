<script setup>
import { ref, onMounted } from "vue";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import profilePhoto from "../assets/profile2.jpg";

// Register ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

const highlights = [
  { num: "01", label: "Education", value: "BS Information Technology @ NCST" },
  {
    num: "02",
    label: "Cross-Platform",
    value: "Desktop UIs in Java Swing & Python PyQt6",
  },
  {
    num: "03",
    label: "Databases",
    value: "Relational MySQL & Multi-Branch Queries",
  },
  {
    num: "04",
    label: "Prototyping",
    value: "Interactive design systems in Figma",
  },
];

const aboutSection = ref(null);
const photoCard = ref(null);
const textContent = ref(null);

onMounted(() => {
  const tl = gsap.timeline({
    scrollTrigger: {
      trigger: aboutSection.value,
      start: "top 75%", // Triggers when the top of the section is 75% down the viewport
      toggleActions: "play none none reverse",
    },
  });

  // Slide photo in from the left
  tl.from(photoCard.value, {
    opacity: 0,
    x: -40,
    duration: 0.8,
    ease: "power3.out",
  })
    // Stagger the text and grid elements sliding up
    .from(
      textContent.value.children,
      { opacity: 0, y: 30, duration: 0.6, stagger: 0.1, ease: "power3.out" },
      "-=0.4",
    );
});
</script>

<template>
  <section
    id="about"
    ref="aboutSection"
    class="flex min-h-screen scroll-mt-24 flex-col justify-center px-6 py-24 md:px-10 overflow-hidden"
  >
    <div
      class="mx-auto grid max-w-7xl grid-cols-1 items-center gap-16 lg:grid-cols-2 lg:gap-20"
    >
      <!-- Left: Framed Photo -->
      <div ref="photoCard" class="relative mx-auto w-full max-w-md">
        <!-- Decorative offset frame (matching Hero style) -->
        <div
          class="pointer-events-none absolute -left-5 -top-5 h-full w-full rounded-[32px] border border-portfolio-accent/25"
        ></div>

        <!-- Bottom-Right Decorative Accent Block -->
        <div
          class="pointer-events-none absolute -bottom-4 -right-4 h-24 w-24 rounded-2xl bg-portfolio-primary/20 backdrop-blur-sm"
        ></div>

        <div
          class="relative z-10 overflow-hidden rounded-[26px] border border-white/10 shadow-2xl shadow-black/50 bg-portfolio-surface"
        >
          <img
            :src="profilePhoto"
            alt="Cho"
            class="h-[520px] w-full object-cover object-top"
          />

          <!-- Top-Right Badge -->
          <div
            class="absolute right-4 top-4 rounded-xl border border-white/10 bg-portfolio-base/90 px-4 py-2 shadow-lg backdrop-blur-md"
          >
            <p
              class="text-[10px] font-semibold uppercase tracking-wider text-portfolio-accent"
            >
              Current Focus
            </p>
            <p class="text-sm font-semibold text-portfolio-text">
              Full-Stack Systems
            </p>
          </div>

          <!-- Bottom Overlay -->
          <div
            class="absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-portfolio-base via-portfolio-base/80 to-transparent px-6 pb-6 pt-16"
          >
            <div>
              <p
                class="text-[10px] font-semibold uppercase tracking-[0.15em] text-portfolio-muted"
              >
                Developer Profile
              </p>
              <p class="text-base font-semibold text-portfolio-text mt-0.5">
                Chowxinn Shanin Lu
              </p>
            </div>

            <!-- Location Badge -->
            <span
              class="flex items-center gap-2 rounded-full border border-white/10 bg-portfolio-surface/90 px-3.5 py-1.5 text-xs font-medium text-portfolio-text backdrop-blur-md"
            >
              <span class="relative flex h-2 w-2">
                <span
                  class="absolute inline-flex h-full w-full animate-ping rounded-full bg-portfolio-accent opacity-75"
                ></span>
                <span
                  class="relative inline-flex h-2 w-2 rounded-full bg-portfolio-accent"
                ></span>
              </span>
              Dasmariñas, Cavite
            </span>
          </div>
        </div>
      </div>

      <!-- Right: Text + Grid -->
      <div ref="textContent">
        <h2
          class="text-5xl font-extrabold text-portfolio-text md:text-6xl tracking-tight"
        >
          About Me
        </h2>

        <p class="mt-6 max-w-xl text-lg text-portfolio-muted leading-relaxed">
          I'm a BSIT student at NCST specializing in full-stack web and
          application development. From prototyping responsive UIs and
          architecting web platforms to building desktop applications and robust
          relational databases, I love building scalable, versatile digital
          solutions.
        </p>

        <!-- Dynamic Grid -->
        <div class="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div
            v-for="item in highlights"
            :key="item.num"
            class="group rounded-xl border border-white/5 bg-portfolio-surface p-5 transition-colors hover:border-portfolio-accent/50"
          >
            <div class="flex items-center justify-between">
              <p
                class="text-[10px] font-semibold uppercase tracking-wider text-portfolio-accent"
              >
                {{ item.label }}
              </p>
              <span
                class="font-mono text-xs text-portfolio-muted group-hover:text-portfolio-accent transition-colors"
                >{{ item.num }}</span
              >
            </div>
            <p
              class="mt-3 text-sm font-medium text-portfolio-text leading-snug"
            >
              {{ item.value }}
            </p>
          </div>
        </div>

        <!-- Currently Exploring Tag -->
        <div
          class="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/5 bg-portfolio-surface px-6 py-4"
        >
          <p
            class="text-xs font-semibold uppercase tracking-wider text-portfolio-muted"
          >
            Currently Exploring:
          </p>
          <span
            class="rounded-full bg-portfolio-primary/20 border border-portfolio-primary/30 px-4 py-1.5 text-sm font-medium text-portfolio-accent"
          >
            Vue 3 Composition API &amp; GSAP
          </span>
        </div>
      </div>
    </div>
  </section>
</template>
