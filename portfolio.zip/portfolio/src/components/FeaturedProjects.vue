<script setup>
import { ref, onMounted } from "vue";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import ecoHydrateImage from "../assets/eco.png";
import bid from "../assets/bid.jpg";
import parking from "../assets/parking.png";
import cinema from "../assets/cinema.png";
import guidance from "../assets/guidance.png";
import banorant from "../assets/banorant.png";

gsap.registerPlugin(ScrollTrigger);

const projectsSection = ref(null);

const projects = [
  {
    id: "01",
    category: "COMMERCE PLATFORM",
    title: "Eco Hydrate",
    description:
      "A multi-branch Point of Sale and web ordering application built for reliable daily operations.",
    tech: ["PHP", "jQuery", "BootStrap CSS", "MySQL"],
    link: "https://github.com/Chowayo/Water-Station-POS",
    image: ecoHydrateImage,
  },
  {
    id: "02",
    category: "AUCTION PLATFORM",
    title: "Auctify",
    description:
      "An artwork auction platform featuring live auction feeds and intelligent auto-bidding logic.",
    tech: ["PHP", "Vue.js", "MySQL", "Tailwind CSS"],
    link: "#",
    image: bid,
  },
  {
    id: "03",
    category: "Parking System",
    title: "Nexus Parking",
    description:
      "A desktop parking management system for logging vehicle entry and exit, tracking slot availability, and generating usage records.",
    tech: ["Java Swing", "JDBC"],
    link: "#",
    image: parking,
  },
  {
    id: "04",
    category: "Cinema System",
    title: "Movie Sphere",
    description:
      "A desktop cinema booking system for browsing showtimes, reserving seats, and managing ticket transactions.",
    tech: ["Python", "PyQt6"],
    link: "#",
    image: cinema,
  },
  {
    id: "05",
    category: "Guidance Appointment Website",
    title: "Evergreen Guidance Appointment",
    description:
      "A web-based scheduling platform for guidance counselors to manage student appointments, availability, and consultation records.",
    tech: ["PHP", "jQuery", "BootStrap CSS", "MySQL"],
    link: "#",
    image: guidance,
  },
  {
    id: "06",
    category: "Static Information Website",
    title: "Banorant",
    description:
      "A static informational website built to present content clearly with clean, lightweight HTML and CSS.",
    tech: ["HTML", "CSS"],
    link: "#",
    image: banorant,
  },
];

onMounted(() => {
  const tl = gsap.timeline({
    scrollTrigger: {
      trigger: projectsSection.value,
      start: "top 75%",
      toggleActions: "play none none reverse",
    },
  });

  tl.from(".projects-header", {
    y: 20,
    opacity: 0,
    duration: 0.6,
    ease: "power3.out",
  }).from(
    ".project-card",
    {
      y: 40,
      opacity: 0,
      duration: 0.6,
      stagger: 0.1,
      ease: "power3.out",
    },
    "-=0.4",
  );
});
</script>

<template>
  <section
    id="work"
    ref="projectsSection"
    class="relative overflow-hidden bg-portfolio-base py-24"
  >
    <!-- Background Grid Overlay (matches global body grid exactly) -->
    <div class="absolute inset-0 z-0 pointer-events-none grid-bg"></div>

    <div class="relative z-10 mx-auto max-w-7xl px-6 md:px-10">
      <!-- Section Header -->
      <div
        class="projects-header mb-16 flex items-end justify-between border-b border-white/10 pb-6"
      >
        <div>
          <p
            class="text-[10px] font-bold uppercase tracking-[0.2em] text-portfolio-accent mb-2"
          >
            FEATURED PROJECTS
          </p>
          <h2
            class="text-4xl font-extrabold text-portfolio-text md:text-5xl tracking-tight"
          >
            Selected Work
          </h2>
        </div>
        <p class="font-mono text-xs text-portfolio-muted/50 hidden md:block">
          01 — 06
        </p>
      </div>

      <!-- Projects Grid (Added group/grid to trigger expansion for all cards at once) -->
      <div
        class="group/grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        <div
          v-for="project in projects"
          :key="project.id"
          class="project-card group/card relative flex flex-col h-full overflow-hidden rounded-2xl border border-white/5 bg-portfolio-surface/60 backdrop-blur-sm p-7 pb-20 transition-colors duration-500 hover:border-portfolio-accent/30 hover:bg-portfolio-surface cursor-pointer shadow-lg"
        >
          <!-- Always Visible Text -->
          <div class="flex-1 flex flex-col">
            <!-- Top Badges -->
            <div class="mb-8 flex items-center justify-between">
              <div
                class="flex items-center gap-2 rounded-full border border-teal-500/20 bg-teal-500/10 px-3 py-1 text-[9px] font-bold tracking-widest text-teal-400"
              >
                <span class="h-1.5 w-1.5 rounded-full bg-teal-400"></span>
                FEATURED
              </div>
              <span class="font-mono text-xs text-portfolio-muted/40">{{
                project.id
              }}</span>
            </div>

            <!-- Typography -->
            <p
              class="mb-2 text-[9px] font-bold uppercase tracking-[0.2em] text-portfolio-muted"
            >
              {{ project.category }}
            </p>
            <h3 class="mb-4 text-2xl font-bold text-portfolio-text">
              {{ project.title }}
            </h3>
            <p class="text-sm leading-relaxed text-portfolio-muted">
              {{ project.description }}
            </p>
          </div>

          <!-- Hidden Expandable Content (Listens to group-hover/grid to expand all simultaneously) -->
          <div
            class="grid grid-rows-[0fr] transition-[grid-template-rows] duration-500 ease-out group-hover/grid:grid-rows-[1fr]"
          >
            <div class="overflow-hidden">
              <div class="pt-6 flex flex-col gap-5">
                <!-- Tech Stack Tags (Listens to group-hover/card to only highlight the specific card you are on) -->
                <div class="flex flex-wrap gap-2">
                  <span
                    v-for="tech in project.tech"
                    :key="tech"
                    class="rounded-md border border-white/10 bg-white/5 px-2.5 py-1 font-mono text-[10px] text-portfolio-muted transition-colors group-hover/card:text-portfolio-accent"
                  >
                    {{ tech }}
                  </span>
                </div>

                <!-- Action Button -->
                <a
                  :href="project.link"
                  class="flex w-full items-center justify-center gap-2 rounded-lg bg-portfolio-primary py-3 text-sm font-semibold text-white transition-all hover:bg-portfolio-accent hover:text-portfolio-base"
                >
                  View Project <span class="font-serif">↗</span>
                </a>

                <!-- Project Screenshot -->
                <div
                  class="mt-2 aspect-video w-full overflow-hidden rounded-xl border border-white/10 bg-portfolio-base shadow-inner"
                >
                  <img
                    :src="project.image"
                    :alt="`${project.title} preview`"
                    class="h-full w-full object-cover"
                    loading="lazy"
                  />
                </div>
              </div>
            </div>
          </div>

          <!-- 'Hover to Explore' Label (Listens to group-hover/grid to fade out all labels simultaneously) -->
          <div
            class="absolute bottom-7 left-7 flex items-center text-[9px] font-bold uppercase tracking-widest text-portfolio-muted transition-all duration-300 group-hover/grid:opacity-0 group-hover/grid:translate-y-2 group-hover/grid:pointer-events-none"
          >
            HOVER TO EXPLORE <span class="ml-2 font-serif text-xs">↓</span>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.grid-bg {
  background-size: 48px 48px;
  background-image:
    linear-gradient(to right, rgba(148, 163, 184, 0.06) 1px, transparent 1px),
    linear-gradient(to bottom, rgba(148, 163, 184, 0.06) 1px, transparent 1px);
}
</style>
