<script setup>
import { ref, onMounted, onBeforeUnmount } from "vue";
import gsap from "gsap";
import makimaPhoto from "../assets/makima.png";
import profilePhoto from "../assets/profile_nobg.jpg";
import { makimaPx, profilePx } from "../assets/pixelFrames.js";

const eyebrowRef = ref(null);
const headlineRef = ref(null);
const paragraphRef = ref(null);
const ctaRef = ref(null);
const cardRef = ref(null);
const badgeRef = ref(null);
const tagRef = ref(null);

// --- Pixelated hover transition ---
// Only random blocks get pixelated: each block flashes as a flat colour
// square of the new photo, then resolves to it sharp, while the rest of the
// photo stays crisp. (No whole-photo blur/mosaic, so it never reads as a
// censor effect.)
const COLS = 12;
const ROWS = 14;
const SPREAD = 260; // ms window in which blocks start flipping at random
const STAGE = 90; // ms a block stays a flat colour square before resolving

const tiles = Array.from({ length: COLS * ROWS }, (_, i) => ({
  col: i % COLS,
  row: Math.floor(i / COLS),
  delay: Math.round(Math.random() * SPREAD),
}));

const phase = ref("idle"); // idle | in | out
const full = ref(false); // seamless sharp layer once every block has flipped
let timer = null;
let fullTimer = null;
const TOTAL = SPREAD + STAGE;

function handleEnter() {
  clearTimeout(timer);
  clearTimeout(fullTimer);
  phase.value = "in";
  fullTimer = setTimeout(() => (full.value = true), TOTAL + 30);
}
function handleLeave() {
  clearTimeout(timer);
  clearTimeout(fullTimer);
  full.value = false;
  phase.value = "out";
  timer = setTimeout(() => (phase.value = "idle"), TOTAL + 60);
}

onMounted(() => {
  const tl = gsap.timeline({ defaults: { ease: "power3.out" } });

  tl.from(eyebrowRef.value, { opacity: 0, y: 16, duration: 0.5 })
    .from(
      headlineRef.value.children,
      { opacity: 0, y: 32, duration: 0.7, stagger: 0.08 },
      "-=0.25",
    )
    .from(paragraphRef.value, { opacity: 0, y: 20, duration: 0.6 }, "-=0.35")
    .from(
      ctaRef.value.children,
      { opacity: 0, y: 16, duration: 0.5, stagger: 0.1 },
      "-=0.3",
    )
    .from(
      cardRef.value,
      { opacity: 0, y: 24, scale: 0.96, duration: 0.8 },
      "-=0.6",
    )
    .from(tagRef.value, { opacity: 0, x: -16, duration: 0.5 }, "-=0.3")
    .from(badgeRef.value, { opacity: 0, scale: 0.8, duration: 0.4 }, "-=0.2");

  // Subtle continuous float on the composite card
  gsap.to(cardRef.value, {
    y: -10,
    duration: 2.6,
    ease: "sine.inOut",
    yoyo: true,
    repeat: -1,
    delay: 1.4,
  });
});

onBeforeUnmount(() => {
  clearTimeout(timer);
  clearTimeout(fullTimer);
});
</script>

<template>
  <section class="relative overflow-hidden">
    <!-- Ambient glow accent -->
    <div
      class="pointer-events-none absolute -top-32 right-0 h-[500px] w-[500px] rounded-full bg-portfolio-primary/20 blur-[120px]"
    ></div>

    <div
      class="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-16 px-6 py-24 md:px-10 lg:grid-cols-2 lg:py-32"
    >
      <!-- Left Column: Pitch & CTAs -->
      <div>
        <p
          ref="eyebrowRef"
          class="mb-6 flex items-center gap-3 text-sm font-medium text-portfolio-accent"
        >
          <span class="h-px w-8 bg-portfolio-accent"></span>
          Hi, I'm a Full-Stack Developer
        </p>

        <h1
          ref="headlineRef"
          class="text-5xl font-extrabold leading-tight text-portfolio-text md:text-6xl"
        >
          <span class="block">Building responsive</span>
          <span class="block">interfaces and</span>
          <span class="block">robust web</span>
          <span class="block text-portfolio-accent">applications.</span>
        </h1>

        <p
          ref="paragraphRef"
          class="mt-6 max-w-md text-lg text-portfolio-muted leading-relaxed"
        >
          I create seamless digital experiences with Vue.js and PHP,
          transforming complex ideas into fast, intuitive, and dependable
          products.
        </p>

        <div ref="ctaRef" class="mt-10 flex flex-wrap items-center gap-4">
          <a
            href="#work"
            class="rounded-lg bg-portfolio-primary px-7 py-3 font-semibold text-portfolio-text shadow-lg shadow-portfolio-primary/30 transition hover:brightness-110"
          >
            View My Work
          </a>
          <a
            href="#contact"
            class="rounded-lg border border-portfolio-muted/30 px-7 py-3 font-semibold text-portfolio-text transition hover:border-portfolio-accent hover:text-portfolio-accent"
          >
            Contact Me
          </a>
        </div>
      </div>

      <!-- Right Column: Framed Visual Card -->
      <div class="relative flex justify-center pt-8 lg:justify-end">
        <div ref="cardRef" class="relative w-full max-w-md">
          <!-- 1. Top-Right Decorative Offset Frame -->
          <div
            class="pointer-events-none absolute -top-5 -right-5 h-full w-full rounded-[32px] border border-portfolio-accent/25"
          ></div>

          <!-- 2. Bottom-Left Decorative Accent Block -->
          <div
            class="pointer-events-none absolute -bottom-5 -left-5 h-28 w-28 rounded-2xl bg-portfolio-primary/35 backdrop-blur-sm"
          ></div>

          <!-- 3. Floating Code Snippet Tag -->
          <div
            ref="tagRef"
            class="absolute -top-5 -left-6 z-20 flex flex-col gap-2 rounded-xl border border-white/10 bg-[#0E1B33]/90 px-4 py-3 shadow-2xl backdrop-blur-md"
          >
            <div class="flex items-center gap-1.5">
              <span class="h-2 w-2 rounded-full bg-rose-400"></span>
              <span class="h-2 w-2 rounded-full bg-amber-400"></span>
              <span class="h-2 w-2 rounded-full bg-emerald-400"></span>
            </div>
            <code class="font-mono text-xs text-slate-200">
              <span class="text-sky-300">const</span> passion =
              <span class="text-emerald-300">"building"</span>;
            </code>
          </div>

          <!-- 4. Main Photo Card -->
          <div
            class="relative z-10 w-full overflow-hidden rounded-[26px] border border-white/10 bg-portfolio-surface shadow-2xl shadow-black/50"
            @mouseenter="handleEnter"
            @mouseleave="handleLeave"
          >
            <!-- Photo swap: random blocks flash as flat pixel squares, then resolve to the other photo -->
            <div class="photo-swap relative h-[540px] w-full">
              <!-- Makima, sharp (resting state) -->
              <img
                :src="makimaPhoto"
                alt="Makima"
                class="absolute inset-0 h-full w-full object-cover object-top"
              />

              <!-- Block grid. Each block has 3 layers: flat profile square,
                   sharp profile slice, flat Makima square (used on the way back). -->
              <div
                class="tile-grid absolute inset-0"
                :class="'phase-' + phase"
                :style="{
                  '--s': STAGE + 'ms',
                  gridTemplateColumns: `repeat(${COLS}, 1fr)`,
                  gridTemplateRows: `repeat(${ROWS}, 1fr)`,
                }"
              >
                <div
                  v-for="(t, i) in tiles"
                  :key="i"
                  class="tile"
                  :style="{ '--d': t.delay + 'ms' }"
                >
                  <div
                    class="tile-inner"
                    :style="{
                      width: COLS * 100 + '%',
                      height: ROWS * 100 + '%',
                      left: -t.col * 100 + '%',
                      top: -t.row * 100 + '%',
                    }"
                  >
                    <div class="layer pxb">
                      <div class="absolute inset-0 bg-portfolio-surface"></div>
                      <img
                        :src="profilePx[2]"
                        alt=""
                        class="profile-img px-layer absolute inset-0 h-full w-full object-cover object-bottom"
                      />
                    </div>
                    <div class="layer shb">
                      <div class="absolute inset-0 bg-portfolio-surface"></div>
                      <img
                        :src="profilePhoto"
                        alt=""
                        class="profile-img absolute inset-0 h-full w-full object-cover object-bottom"
                      />
                    </div>
                    <div class="layer pxa">
                      <img
                        :src="makimaPx[2]"
                        alt=""
                        class="px-layer absolute inset-0 h-full w-full object-cover object-top"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <!-- Seamless sharp profile layer, swapped in once all blocks have flipped -->
              <div
                class="absolute inset-0 overflow-hidden"
                :style="{ opacity: full ? 1 : 0 }"
              >
                <div class="absolute inset-0 bg-portfolio-surface"></div>
                <img
                  :src="profilePhoto"
                  alt="Profile photo"
                  class="profile-img absolute inset-0 h-full w-full object-cover object-bottom"
                />
              </div>
            </div>

            <!-- Bottom Gradient Overlay -->
            <div
              class="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-end justify-between bg-gradient-to-t from-portfolio-base via-portfolio-base/60 to-transparent px-6 pb-6 pt-20"
            >
              <div>
                <p
                  class="font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-portfolio-accent"
                >
                  Full-Stack Developer
                </p>
                <p class="mt-1 text-base font-semibold text-portfolio-text">
                  Code, craft &amp; curiosity
                </p>
              </div>

              <!-- Status Badge -->
              <div
                ref="badgeRef"
                class="pointer-events-auto flex items-center gap-2 rounded-full border border-white/10 bg-portfolio-base/80 px-3.5 py-1.5 text-xs font-medium text-portfolio-text backdrop-blur-md"
              >
                <span class="relative flex h-2 w-2">
                  <span
                    class="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75"
                  ></span>
                  <span
                    class="relative inline-flex h-2 w-2 rounded-full bg-emerald-400"
                  ></span>
                </span>
                Available
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.photo-swap {
  isolation: isolate;
}

.photo-swap > img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: top center;
}

/* profile_nobg's subject only occupies a small part of its canvas, so zoom
   in anchored at the bottom to match Makima's framing. */
.profile-img {
  transform: scale(1.5);
  transform-origin: center bottom;
}

/* Tiny pre-pixelated images, scaled up with no smoothing = flat blocks. */
.px-layer {
  image-rendering: crisp-edges;
  image-rendering: pixelated;
}

.tile-grid {
  display: grid;
  pointer-events: none;
}
.tile {
  position: relative;
  overflow: hidden;
}
.tile-inner {
  position: absolute;
}

/* All cuts are hard (0s transitions); only the delays create the rhythm. */
.layer {
  position: absolute;
  inset: 0;
  opacity: 0;
  transition: opacity 0s linear;
}

/* hover in: flat square at its random moment, sharp photo --s later */
.phase-in .pxb {
  opacity: 1;
  transition-delay: var(--d);
}
.phase-in .shb {
  opacity: 1;
  transition-delay: calc(var(--d) + var(--s));
}

/* hover out: sharp profile -> flat Makima square -> sharp Makima */
.phase-out .pxb,
.phase-out .shb {
  transition-delay: calc(var(--d) + var(--s));
}
.phase-out .pxa {
  animation: flat-flash var(--s) steps(1, end) var(--d) 1 forwards;
}
@keyframes flat-flash {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
</style>
