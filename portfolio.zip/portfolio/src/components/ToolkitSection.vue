<script setup>
import { ref, onMounted } from "vue";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const skillsSection = ref(null);
const marqueeTrack = ref(null);
const marqueeTrackBg = ref(null);

const skills = [
  { id: "01", icon: "vuedotjs", color: "4FC08D", name: "Vue.js", category: "FRONTEND", percent: 90 },
  {
    id: "02",
    icon: "tailwindcss",
    color: "06B6D4",
    name: "Tailwind CSS",
    category: "FRONTEND",
    percent: 92,
  },
  {
    id: "03",
    icon: "javascript",
    color: "F7DF1E",
    name: "JavaScript",
    category: "FRONTEND",
    percent: 88,
  },
  { id: "04", icon: "html5", color: "E34F26", name: "HTML", category: "FRONTEND", percent: 95 },
  { id: "05", icon: "css", color: "1572B6", name: "CSS", category: "FRONTEND", percent: 90 },
  { id: "06", icon: "php", color: "777BB4", name: "PHP", category: "BACKEND", percent: 88 },
  { id: "07", icon: "mysql", color: "4479A1", name: "MySQL", category: "BACKEND", percent: 84 },
  { id: "08", icon: "figma", color: "F24E1E", name: "Figma", category: "DESIGN", percent: 82 },
];

onMounted(() => {
  // 1. Foreground Marquee (Fast, moving Left)
  gsap.to(marqueeTrack.value, {
    xPercent: -50,
    ease: "none",
    duration: 15,
    repeat: -1,
  });

  // 2. Background Marquee (Slow, moving Right for parallax effect)
  gsap.fromTo(
    marqueeTrackBg.value,
    { xPercent: -50 },
    {
      xPercent: 0,
      ease: "none",
      duration: 25,
      repeat: -1,
    },
  );

  // 3. Animate Cards Staggering In
  const cards = skillsSection.value.querySelectorAll(".skill-card");
  gsap.from(cards, {
    scrollTrigger: {
      trigger: skillsSection.value,
      start: "top 75%",
      toggleActions: "play none none reverse",
    },
    y: 40,
    opacity: 0,
    duration: 0.6,
    stagger: 0.1,
    ease: "power3.out",
  });

  // 4. Animate Progress Bars Filling Up
  const bars = skillsSection.value.querySelectorAll(".progress-fill");
  bars.forEach((bar) => {
    gsap.to(bar, {
      scrollTrigger: {
        trigger: skillsSection.value,
        start: "top 65%",
        toggleActions: "play none none reverse",
      },
      width: bar.dataset.targetWidth + "%",
      duration: 1.2,
      ease: "power3.out",
      delay: 0.3,
    });
  });
});
</script>

<template>
  <section
    id="skills"
    ref="skillsSection"
    class="relative overflow-hidden bg-portfolio-base py-24"
  >
    <!-- Background Grid Overlay (matches global body grid exactly) -->
    <div class="absolute inset-0 z-0 pointer-events-none grid-bg"></div>

    <!-- Dual Marquee Section -->
    <div class="relative flex h-32 w-full items-center justify-center my-8">
      <!-- Background Marquee (Dark/Muted) -->
      <div
        class="absolute w-full max-w-[100vw] rotate-[2deg] scale-105 border-y border-white/5 bg-portfolio-base/90 py-3 shadow-md overflow-hidden z-0"
      >
        <div ref="marqueeTrackBg" class="flex whitespace-nowrap w-[200%]">
          <div
            v-for="i in 4"
            :key="'bg-' + i"
            class="flex items-center gap-12 px-12 text-[10px] font-bold tracking-[0.3em] uppercase text-portfolio-muted"
          >
            <span>FRONTEND</span>
            <span class="text-portfolio-primary text-[10px]">♦</span>
            <span>WEB DEVELOPMENT</span>
            <span class="text-portfolio-primary text-[10px]">♦</span>
            <span>BACKEND</span>
            <span class="text-portfolio-primary text-[10px]">♦</span>
            <span>UI DESIGN</span>
            <span class="text-portfolio-primary text-[10px]">♦</span>
          </div>
        </div>
      </div>

      <!-- Foreground Marquee (Purple) -->
      <div
        class="absolute w-full max-w-[100vw] rotate-[-2deg] scale-105 bg-portfolio-primary py-4 shadow-2xl overflow-hidden z-10"
      >
        <div ref="marqueeTrack" class="flex whitespace-nowrap w-[200%]">
          <div
            v-for="i in 4"
            :key="'fg-' + i"
            class="flex items-center gap-8 px-8 text-2xl font-black text-white tracking-[0.2em] uppercase"
          >
            <span>MY SKILLS</span>
            <div
              class="flex h-5 w-5 items-center justify-center rounded-full border border-white/40 text-xs font-light"
            >
              +
            </div>
            <span>MY TOOLKIT</span>
            <div
              class="flex h-5 w-5 items-center justify-center rounded-full border border-white/40 text-xs font-light"
            >
              +
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Skills Grid Content -->
    <div class="relative z-10 mx-auto mt-20 max-w-7xl px-6 md:px-10">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <!-- Dynamic Render of Skill Cards -->
        <div
          v-for="skill in skills"
          :key="skill.id"
          class="skill-card rounded-2xl border border-white/5 bg-portfolio-surface/90 p-5 shadow-lg backdrop-blur-sm transition-colors hover:border-portfolio-accent/30"
        >
          <!-- Card Header (Icon, Title, ID) -->
          <div class="flex items-start justify-between">
            <div class="flex items-center gap-4">
              <!-- Outline Badge -->
              <div
                class="flex h-10 w-10 items-center justify-center rounded-full border border-portfolio-accent/30 bg-portfolio-base/50 p-2"
              >
                <img
                  :src="`https://cdn.simpleicons.org/${skill.icon}/${skill.color}`"
                  :alt="skill.name"
                  class="h-full w-full object-contain"
                  loading="lazy"
                />
              </div>
              <div>
                <h3 class="text-base font-bold text-portfolio-text">
                  {{ skill.name }}
                </h3>
                <p
                  class="text-[9px] font-bold uppercase tracking-[0.2em] text-portfolio-muted mt-1"
                >
                  {{ skill.category }}
                </p>
              </div>
            </div>

            <!-- Card Number -->
            <span
              class="font-mono text-xs font-medium text-portfolio-muted/50"
              >{{ skill.id }}</span
            >
          </div>

          <!-- Progress Bar Section -->
          <div class="mt-5">
            <div class="mb-2 flex items-center justify-between">
              <span
                class="text-[9px] font-bold uppercase tracking-[0.2em] text-portfolio-muted"
                >Proficiency</span
              >
              <span class="font-mono text-xs font-semibold text-portfolio-text"
                >{{ skill.percent }}%</span
              >
            </div>

            <!-- Track -->
            <div
              class="h-1.5 w-full overflow-hidden rounded-full bg-portfolio-base shadow-inner"
            >
              <!-- Fill (Width animated by GSAP) -->
              <div
                class="progress-fill h-full rounded-full bg-portfolio-accent/90"
                :data-target-width="skill.percent"
                style="width: 0%"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.grid-bg {
  background-size: 48px 48px;
  background-image:
    linear-gradient(to right, rgba(148, 163, 184, 0.06) 1px, transparent 1px),
    linear-gradient(to bottom, rgba(148, 163, 184, 0.06) 1px, transparent 1px);
}
</style>

