<script setup>
import { ref, onMounted } from "vue";
import gsap from "gsap";

const navRef = ref(null);
const mobileOpen = ref(false);
const isDark = ref(true);

const links = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Work", href: "#work" },
  { label: "Contact", href: "#contact" },
];

function closeMobile() {
  mobileOpen.value = false;
}

const toggleTheme = () => {
  // Fallback for browsers that don't support View Transitions
  if (!document.startViewTransition) {
    executeThemeSwap();
    return;
  }

  // Trigger the diagonal slide transition
  document.startViewTransition(() => {
    executeThemeSwap();
  });
};

const executeThemeSwap = () => {
  isDark.value = !isDark.value;
  if (isDark.value) {
    document.documentElement.classList.add("dark");
    localStorage.setItem("theme", "dark");
  } else {
    document.documentElement.classList.remove("dark");
    localStorage.setItem("theme", "light");
  }
};

onMounted(() => {
  if (localStorage.getItem("theme") === "light") {
    isDark.value = false;
    document.documentElement.classList.remove("dark");
  } else {
    document.documentElement.classList.add("dark");
  }

  gsap.from(navRef.value, {
    opacity: 0,
    y: -16,
    duration: 0.5,
    ease: "power3.out",
  });
});
</script>

<template>
  <header
    ref="navRef"
    class="fixed top-0 left-0 w-full z-50 border-b border-portfolio-muted/10 bg-portfolio-base/80 backdrop-blur-md"
  >
    <nav
      class="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 md:px-10"
    >
      <!-- logo -->
      <a href="#" class="flex items-center gap-3">
        <span
          class="flex h-8 w-8 items-center justify-center rounded-lg bg-portfolio-primary text-sm font-bold text-white shadow-lg shadow-portfolio-primary/30"
        >
          C
        </span>
        <span class="font-semibold text-portfolio-text">Chowayo</span>
      </a>

      <!-- Right side controls -->
      <div class="flex items-center gap-4 md:gap-8">
        <!-- desktop links -->
        <ul class="hidden items-center gap-8 md:flex">
          <li v-for="link in links" :key="link.href">
            <a
              :href="link.href"
              class="text-sm font-medium text-portfolio-muted transition hover:text-portfolio-accent"
            >
              {{ link.label }}
            </a>
          </li>
        </ul>

        <!-- theme toggle -->
        <button
          @click="toggleTheme"
          class="flex h-9 w-9 items-center justify-center rounded-lg border border-portfolio-muted/20 text-portfolio-text transition-colors hover:bg-portfolio-surface hover:text-portfolio-accent"
          aria-label="Toggle Light/Dark Mode"
        >
          <svg
            v-if="isDark"
            class="h-4 w-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
            ></path>
          </svg>
          <svg
            v-else
            class="h-4 w-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
            ></path>
          </svg>
        </button>

        <!-- mobile menu toggle -->
        <button
          class="flex h-9 w-9 items-center justify-center rounded-lg border border-portfolio-muted/20 text-portfolio-text md:hidden transition-colors hover:bg-portfolio-surface hover:text-portfolio-accent"
          @click="mobileOpen = !mobileOpen"
          aria-label="Toggle menu"
        >
          <svg
            v-if="!mobileOpen"
            class="h-5 w-5"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
          <svg
            v-else
            class="h-5 w-5"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      </div>
    </nav>

    <!-- mobile menu dropdown -->
    <div
      v-if="mobileOpen"
      class="flex flex-col gap-1 border-t border-portfolio-muted/10 bg-portfolio-base px-6 py-4 md:hidden"
    >
      <a
        v-for="link in links"
        :key="link.href"
        :href="link.href"
        class="rounded-lg px-3 py-2 text-sm font-medium text-portfolio-muted transition hover:bg-portfolio-surface hover:text-portfolio-accent"
        @click="closeMobile"
      >
        {{ link.label }}
      </a>
    </div>
  </header>
</template>
