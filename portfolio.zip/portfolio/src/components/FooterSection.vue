<script setup>
const exploreLinks = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Selected Work", href: "#work" },
  { label: "Contact", href: "#contact" },
];

const connectLinks = [
  { label: "GitHub", href: "https://github.com/Chowayo", external: true },
  { label: "LinkedIn", href: "https://linkedin.com/in/", external: true },
  { label: "Send a message", href: "#contact", external: false },
];

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: "smooth" });
}
</script>

<template>
  <footer class="relative border-t border-white/5 bg-portfolio-base">
    <div class="mx-auto max-w-7xl px-6 py-16 md:px-10">
      <div class="grid grid-cols-1 gap-12 md:grid-cols-[1.3fr_1fr_1fr]">
        <!-- Brand column -->
        <div>
          <a href="#" class="flex items-center gap-3">
            <span
              class="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-portfolio-primary to-portfolio-accent text-xs font-bold text-portfolio-text"
            >
              CSL
            </span>
            <span class="font-semibold text-portfolio-text">chowxinn.dev</span>
          </a>

          <p class="mt-6 max-w-xs text-sm leading-relaxed text-portfolio-muted">
            Building thoughtful digital experiences from Dasmariñas, Cavite —
            one clean line of code at a time.
          </p>

          <div
            class="mt-6 inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1.5"
          >
            <span class="relative flex h-2 w-2">
              <span
                class="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75"
              ></span>
              <span
                class="relative inline-flex h-2 w-2 rounded-full bg-emerald-400"
              ></span>
            </span>
            <span class="text-xs font-medium text-emerald-300">
              Available for opportunities
            </span>
          </div>
        </div>

        <!-- Explore column -->
        <div>
          <h3
            class="text-[11px] font-bold uppercase tracking-[0.2em] text-portfolio-muted"
          >
            Explore
          </h3>
          <ul class="mt-5 space-y-3">
            <li v-for="link in exploreLinks" :key="link.label">
              <a
                :href="link.href"
                class="text-sm text-portfolio-muted transition hover:text-portfolio-accent"
              >
                {{ link.label }}
              </a>
            </li>
          </ul>
        </div>

        <!-- Connect column -->
        <div>
          <h3
            class="text-[11px] font-bold uppercase tracking-[0.2em] text-portfolio-muted"
          >
            Connect
          </h3>
          <ul class="mt-5 space-y-3">
            <li v-for="link in connectLinks" :key="link.label">
              <a
                :href="link.href"
                :target="link.external ? '_blank' : undefined"
                :rel="link.external ? 'noopener noreferrer' : undefined"
                class="inline-flex items-center gap-1 text-sm text-portfolio-muted transition hover:text-portfolio-accent"
              >
                {{ link.label }}
                <svg
                  v-if="link.external"
                  class="h-3 w-3"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M7 17L17 7M7 7h10v10"
                  />
                </svg>
              </a>
            </li>
          </ul>
        </div>
      </div>

      <!-- Bottom bar -->
      <div
        class="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-6 text-xs text-portfolio-muted md:flex-row"
      >
        <p>&copy; 2026 Chowxinn Shanin Lu. All rights reserved.</p>

        <div class="flex items-center gap-4">
          <p>
            Designed &amp; built with
            <span class="font-medium text-portfolio-text">Vue + Vite</span>
          </p>
          <button
            @click="scrollToTop"
            aria-label="Back to top"
            class="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-portfolio-text transition hover:border-portfolio-accent/40 hover:text-portfolio-accent"
          >
            <svg
              class="h-4 w-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M5 15l7-7 7 7"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  </footer>
</template>
