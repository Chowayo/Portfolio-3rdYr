/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{vue,js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        "portfolio-base": "rgba(var(--color-base), <alpha-value>)",
        "portfolio-surface": "rgba(var(--color-surface), <alpha-value>)",
        "portfolio-primary": "rgba(var(--color-primary), <alpha-value>)",
        "portfolio-accent": "rgba(var(--color-accent), <alpha-value>)",
        "portfolio-text": "rgba(var(--color-text), <alpha-value>)",
        "portfolio-muted": "rgba(var(--color-muted), <alpha-value>)",
      },
    },
  },
  plugins: [],
};
